#ifndef PROJECT_USAGE_TEST_TEST_SUITE_H
#define PROJECT_USAGE_TEST_TEST_SUITE_H

#include <check.h>

#define MAX_TESTS_IN_SUITE 20
void add_tests(size_t const n, TTest const * tests[n]);

#endif /* PROJECT_USAGE_TEST_TEST_SUITE_H */

